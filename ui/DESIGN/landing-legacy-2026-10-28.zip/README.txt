WorkStep 旧版官网备份 · 2026-10-28
基于提交 09377f50，保留改版前布局、录屏、动画和手册。
按用户要求同步移除免费宣传，条款与隐私采用匿名多语言正文。
打开 site/index.html；请保留同级 assets 目录。source 包含可重新构建的源码。
重建：在 source 中 yarn install --frozen-lockfile，然后 LANDING_BASE=./ yarn build。
