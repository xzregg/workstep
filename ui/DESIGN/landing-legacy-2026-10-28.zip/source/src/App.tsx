import { useEffect, useState } from 'react'
import { ManualPage } from './manual/ManualPage'
import { getManualChapterId, isManualHash } from './manual/content'
import { Compare } from './components/Compare'
import { Channels } from './components/Channels'
import { Demos } from './components/Demos'
import { DemoModal } from './components/DemoModal'
import { EnginesStrip } from './components/EnginesStrip'
import { Features } from './components/Features'
import { FinalCta } from './components/FinalCta'
import { Footer } from './components/Footer'
import { Hero } from './components/Hero'
import { Nav } from './components/Nav'
import { Philosophy } from './components/Philosophy'
import { RemoteShare } from './components/RemoteShare'
import { Workflow } from './components/Workflow'
import type { DemoDef } from './demo/demos'
import { getExperienceHref } from './config/entryPoints'
import { PrivacyPage } from './components/PrivacyPage'
import { TermsPage } from './components/TermsPage'

function scrollToDemos() {
  document.getElementById('demos')?.scrollIntoView({ behavior: window.matchMedia('(prefers-reduced-motion: reduce)').matches ? 'auto' : 'smooth' })
}

export default function App() {
  const [hash, setHash] = useState(() => typeof window === 'undefined' ? '' : window.location.hash)
  useEffect(() => {
    const update = () => setHash(window.location.hash)
    window.addEventListener('hashchange', update)
    return () => window.removeEventListener('hashchange', update)
  }, [])
  useEffect(() => {
    if (isManualHash(hash) || hash === '#privacy' || hash === '#terms') window.scrollTo(0, 0)
    else if (hash) document.getElementById(hash.slice(1))?.scrollIntoView()
  }, [hash])
  const [openDemo, setOpenDemo] = useState<DemoDef | null>(null)
  const experienceHref = getExperienceHref(typeof window === 'undefined' ? '' : window.location.pathname)

  return (
    <>
      <Nav />
      {isManualHash(hash) ? <ManualPage chapterId={getManualChapterId(hash)} /> : hash === '#privacy' ? <PrivacyPage /> : hash === '#terms' ? <TermsPage /> : <main>
        <Hero onOpenDemos={scrollToDemos} experienceHref={experienceHref} />
        <Philosophy />
        <Demos onOpen={setOpenDemo} />
        <Features />
        <EnginesStrip />
        <Workflow />
        <Compare />
        <Channels />
        <RemoteShare />
        <FinalCta experienceHref={experienceHref} />
      </main>}
      <Footer />
      {openDemo && <DemoModal demo={openDemo} onClose={() => setOpenDemo(null)} />}
    </>
  )
}
